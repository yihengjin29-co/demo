import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './styles.css';
import './overrides.css';
import './dashboard/dashboard.css';
import './dashboard/group-dashboard.css';

createRoot(document.getElementById('root')!).render(<React.StrictMode><App /></React.StrictMode>);
